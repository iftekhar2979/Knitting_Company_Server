function requestedId(req){
    return parseFloat(req.params.id)
    }

    module.exports={requestedId}