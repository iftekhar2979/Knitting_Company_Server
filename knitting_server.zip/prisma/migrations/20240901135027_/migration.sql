-- DropForeignKey
ALTER TABLE `billinformation` DROP FOREIGN KEY `BillInformation_orderId_fkey`;
