-- AlterTable
ALTER TABLE `company` ADD COLUMN `shortForm` VARCHAR(191) NULL;
