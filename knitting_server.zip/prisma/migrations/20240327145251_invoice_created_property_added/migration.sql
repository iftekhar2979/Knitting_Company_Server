-- AlterTable
ALTER TABLE `order` ADD COLUMN `isProformaInvoiceCreated` BOOLEAN NOT NULL DEFAULT false;
